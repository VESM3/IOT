# VESM3_Lokverk

## Members
- Andri (Belistov)
- Alexander (Wiselt)
- Matthías (Snubble)
- Mateus (Moonlet)
- Stefán (barasta1)

## Ideas
BMO and NEPTR from Adventure Time.<br>

## Features
- Idol
  - Face that justs blinks and more ???
- Button
  - Turns on some game like flappy bird or something like that
- Joystick
  - Controller for the game


## BMO
### Raspberry Pi
IP-number: 10.201.48.63

#### Connect to Raspberry Pi via SSH (command prompt/terminal)
`ssh pi@10.201.48.63`, password: `raspberry`

#### Connect to Raspberry Pi with GUI
* Download [RealVNC Viewer](https://www.realvnc.com/en/connect/download/viewer/)
* Log-in unnecessary
* File > New Connection
  * VNC Server: `10.201.48.63`
  * OK
* Password: `raspberry`

#### Access Node-RED through VNC Viewer
If not already running, open terminal and type `node-red` to boot up Node-RED.
Open `http://localhost:1880/` in browser.


### MQTT Broker
#### Send data from ESP to Raspberry Pi
```py
MQTT_BROKER = "10.201.48.63"
CLIENT_ID = ...
TOPIC = ...

mqtt_client = MQTTClient(CLIENT_ID, MQTT_BROKER, keepalive=60)
```
Also see `code/esp.py` for example usage.

#### Receive data to Raspberry Pi through Node-RED
See *Access Node-RED through VNC Viewer* to connect to Raspberry Pi with GUI

In Node-RED, use the `Network > MQTT in` node.
* Server > edit
  * Server: `10.201.48.63`
  * Port: `1883` (should be default)
  * Connect automatically
  * Protocol: `MQTT V3.1.1`
  * Client ID: leave blank
  * Keep alive: 60
* Action: `Subscribe to single topic`
* Topic: the topic you set in the Python code on the ESP (use different topics for different data)
* QoS: `2`
* Output: `auto-detect`
* Done

Node-RED should now be receiving data from the ESP.

### BMO Checklist
- [x] Display
- [x] Audio
- [x] Node-RED set up on Raspberry Pi (MQTT Broker to send data over to RPi)
- [ ] Display sync to audio

\+ ...


### Build

B.M.O(blái kasinn),
Settum Raspberry pi inn í B.M.O 
sem er með hlutverkið af Broker og stjórnar led skjá(64x64 RGB LED Matrix).
Annars er hann líka með ESP-32 sem er notaður í að stjórna m.a., speakers,mp3 spilari og er með samskipti með Node-Red.

### Orbylgjuofninn, 
Festum tveimur Servo motors við orbylgjuofninn sem eru stjórnaðir af ESP-32. 
ESP-32 er líka með samskipti við Node-Red 

### Tilgangur

Þegar það er ýtt á takkan hjá B.M.O mun hann spilar hljóð og breyta andlitinu sínu.
Eftir það mun orbylgjuofninn hreyfa Servo motorana og senan endar.
