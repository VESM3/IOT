from umqtt.simple import MQTTClient
from machine import Pin, ADC
import time
from dfplayer import DFPlayer
from random import randint

AUDIO_PIN = ADC(Pin(6), atten=ADC.ATTN_11DB)
BUTTON_PIN = Pin(11, Pin.IN, Pin.PULL_UP)

button_last_value = 1

# ------------
# WLAN set-up

WLAN_SSID = 'TskoliVESM'
WLAN_PASSWORD = 'Fallegurhestur'

def wlan_connect():
    import network
    
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    
    if not wlan.isconnected():
        print('Connecting to network...')
        
        wlan.connect(WLAN_SSID, WLAN_PASSWORD)
        
        while not wlan.isconnected():
            pass
        
    print('IFCONFIG:', wlan.ifconfig())
    
wlan_connect()

# ------------
# DFPlayer set-up

df=DFPlayer(uart_id=2,tx_pin_id=4,rx_pin_id=5)
time.sleep(0.2)
df.volume(25)
time.sleep(0.2)
time.sleep(0.2)
print(df.get_volume())

# ------------
# MQTT set-up

MQTT_BROKER = "10.201.48.63"
CLIENT_ID = "esp1"

VOLUME_TOPIC = b"BMO_Volume" # Subscribe <- Audio ESP32
LOUDNESS_TOPIC = b"BMO_Loudness" # Publish -> RPi display
SCENE_TOPIC = b"BMO_Scene" # Publish

mqtt_client = MQTTClient(CLIENT_ID, MQTT_BROKER, keepalive=60)

def on_message(topic, payload):
    message = payload.decode()
    
    df.volume(int(message))

while True:
    try:
        mqtt_client.connect()
    except Exception as err:
        continue
    break

mqtt_client.set_callback(on_message)
mqtt_client.subscribe(VOLUME_TOPIC)

# ------------
# Run loop

while True:
    # Get audio loudness and button state
    loudness = str(AUDIO_PIN.read())
    print(loudness)
    button_value = BUTTON_PIN.value()
    
    start_scene = False
    
    # If button pressed
    if (button_value == 0) and (button_last_value == 1):
        print('Click')
        df.play(1, randint(1, 4))
        
        start_scene = True
    
    button_last_value = button_value
    
    # Send data
    try:
        mqtt_client.check_msg()
        mqtt_client.publish(LOUDNESS_TOPIC, loudness)
        
        if start_scene:
            mqtt_client.publish(SCENE_TOPIC, 'trigger')
    except Exception as err:
        print(err)
        
        while True:
            try:
                mqtt_client.set_callback(fekk_skilabod)
                mqtt_client.connect()
                mqtt_client.subscribe(TOPIC_AFTUR)
            except Exception as err:
                continue
            break
        
    time.sleep_ms(100)






