from machine import Pin, ADC
from time import sleep_ms

from umqtt.simple import MQTTClient

resistor = ADC(Pin(8), atten=ADC.ATTN_11DB)

# -------------
WIFI_SSID = 'TskoliVESM'
WIFI_LYKILORD = 'Fallegurhestur'

def do_connect():
    import network
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print('connecting to network...')
        wlan.connect(WIFI_SSID, WIFI_LYKILORD)
        while not wlan.isconnected():
            pass
    print('network config:', wlan.ifconfig())
    
do_connect()
# -------------

MQTT_BROKER = "10.201.48.63"
CLIENT_ID = "esp1"
TOPIC = b"testTopic"

mqtt_client = MQTTClient(CLIENT_ID, MQTT_BROKER, keepalive=60)

while True:
    print('Tilraun')
    try:
        mqtt_client.connect()
        print('Tenging tókst')
    except Exception as err:
        print('Ekki tókst að tengjast - fyrsta tenging:', err)
        continue
    break

while True:
    value = str(resistor.read())
    print(value)
    
    try:
        mqtt_client.publish(TOPIC, value)
        print('Tókst að senda skilaboð')
    except Exception as err:
        print('Ekki tókst að senda skilaboð:', err)
        
        while True:
            try:
                mqtt_client.set_callback(fekk_skilabod)
                mqtt_client.connect()
                mqtt_client.subscribe(TOPIC_AFTUR)
            except Exception as err:
                print('Ekki tókst að tengjast - endurtenging:', err)
                continue
            break
        
    sleep_ms(100)

