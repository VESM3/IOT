from machine import Pin, PWM
import time
from umqtt.simple import MQTTClient

p0 = Pin(4, Pin.OUT)

# -------------
WIFI_SSID = 'TskoliVESM'
WIFI_LYKILORD = 'Fallegurhestur'

def do_connect():
    import network
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print('connecting to network...')
        wlan.connect(WIFI_SSID, WIFI_LYKILORD)
        while not wlan.isconnected():
            pass
    print('network config:', wlan.ifconfig())
    
do_connect()
# -------------

def on_message(topic, payload): main()

MQTT_BROKER = "10.201.48.63"
CLIENT_ID = "esp2"
TOPIC = b"Neptr_Scene"

mqtt_client = MQTTClient(CLIENT_ID, MQTT_BROKER, keepalive=60)


class myServo(object):
    def __init__(self, pin: int=15, hz: int=50):
        self._servo = PWM(Pin(pin), hz) 
    
    def myServoWriteDuty(self, duty):
        if duty <= 26:
            duty = 26
        if duty >= 128:
            duty = 128
        self._servo.duty(duty)
        
    def myServoWriteAngle(self, pos):
        if pos <= 0:
            pos = 0
        if pos >= 180:
            pos = 180
        pos_buffer = (pos / 180) * (128 - 26)
        self._servo.duty(int(pos_buffer) + 26)

    def myServoWriteTime(self, us):
        if us <= 500:
            us = 500
        if us >= 2500:
            us = 2500
        pos_buffer = (1024 * us) / 20000
        self._servo.duty(int(pos_buffer))
        
    def deinit(self):
        self._servo.deinit()
        
class myServo2(object):
    def __init__(self, pin: int=15, hz: int=50):
        self._servo = PWM(Pin(pin), hz) 
    
    def myServoWriteDuty2(self, duty):
        if duty <= 26:
            duty = 26
        if duty >= 128:
            duty = 128
        self._servo.duty(duty)
        
    def myServoWriteAngle2(self, pos):
        if pos <= 20:
            pos = 20
        if pos >= 65:
            pos = 65
        pos_buffer = (pos / 45) * (128 - 26)
        self._servo.duty(int(pos_buffer) + 26)

    def myServoWriteTime2(self, us):
        if us <= 500:
            us = 500
        if us >= 2500:
            us = 2500
        pos_buffer = (1024 * us) / 20000
        self._servo.duty(int(pos_buffer))
        
    def deinit2(self):
        self._servo.deinit()

# Initialize the servo
servo = myServo(10) # Pin connected to the servo

# Define the number of steps and delay between steps (in seconds)
num_steps = 180  # Total steps for one full rotation
delay = 0.01  # Delay between each step (adjust for desired speed)

# Initialize the servo
servo2 = myServo2(9) # Pin connected to the servo

# Define the number of steps and delay between steps (in seconds)
num_steps2 = 45  # Total steps for one full rotation

def main():
    p0.value(1)
    # Rotate the servo motor 360 degrees
    for _ in range(num_steps2):
        servo2.myServoWriteAngle2(_)
        time.sleep(delay)
    
    # Rotate back to 0 degrees
    for _ in range(num_steps2, -1, -1):
        servo2.myServoWriteAngle2(_)
        time.sleep(delay)
        
    # Rotate the servo motor 360 degrees
    for _ in range(num_steps):
        servo.myServoWriteAngle(_)
        time.sleep(delay)
    
    # Rotate back to 0 degrees
    for _ in range(num_steps, -1, -1):
        servo.myServoWriteAngle(_)
        time.sleep(delay)
    p0.value(0)

while True:
    print('Tilraun')
    try:
        mqtt_client.connect()
        print('Tenging tókst')
    except Exception as err:
        print('Ekki tókst að tengjast - fyrsta tenging:', err)
        continue
    break


mqtt_client.set_callback(on_message)
mqtt_client.subscribe(TOPIC)

while True:
    try:
        mqtt_client.check_msg()
    except Exception as err:
        print('Ekki tókst að senda skilaboð:', err)
        
        while True:
            try:
                mqtt_client.set_callback(fekk_skilabod)
                mqtt_client.connect()
                mqtt_client.subscribe(TOPIC_AFTUR)
            except Exception as err:
                print('Ekki tókst að tengjast - endurtenging:', err)
                continue
            break
        
    time.sleep_ms(100)
    
    
# Cleanup (this will never be reached in this script as it's an infinite loop)
servo.deinit()

