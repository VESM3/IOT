from machine import Pin, ADC
from time import sleep_ms

stick_x = ADC(Pin(9), atten=ADC.ATTN_11DB)
stick_y = ADC(Pin(8), atten=ADC.ATTN_11DB)
stick_button = Pin(7, Pin.IN, Pin.PULL_UP)

while True:
    print(f"X: {stick_x.read()}, Y: {stick_y.read()}, Takki: {stick_button.value()}")
    sleep_ms(60)