#!/usr/bin/env python3

import time
import sys

from rgbmatrix import RGBMatrix, RGBMatrixOptions
from PIL import Image

image_files = ['face-neutral.png', 'face-smile.png', 'face-talk1.png']

images = []
for image_file in image_files:
    images.append(Image.open(image_file))
    
print(images)

# Configuration for the matrix
options = RGBMatrixOptions()
options.rows = 64
options.cols = 64
options.chain_length = 1
options.parallel = 1
options.hardware_mapping = 'adafruit-hat' 

matrix = RGBMatrix(options=options)

try:
    while True:
        for image in images:
            print(image)
            matrix.SetImage(image.convert('RGB'))
            time.sleep(0.5)
            
except KeyboardInterrupt:
    sys.exit(0)

