# FORR3FV - Verkefni 5

Verkefni 5 (lokaverkefni - LED Matrix) í FORR3FV05EU (viðmótsforritun), haustönn 2019, tölvubraut í Tækniskólanum.

Lesa má um verkefnið á [GitHub Pages-síðu þess](https://reyniraron.github.io/vf-verkefni-5).
